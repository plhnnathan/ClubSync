async function navigate(view) {
  if (!authToken) {
    renderLogin();
    return;
  }

  // Load and apply club branding if not cached yet
  if (!localStorage.getItem("clubName")) {
    try {
      const { data } = await request("GET", "/club");
      if (data) {
        localStorage.setItem("clubColor", data.primaryColor || "#00c853");
        localStorage.setItem("clubSecondary", data.secondaryColor || "#3b82f6");
        localStorage.setItem("clubLogo", data.logoUrl || "");
        localStorage.setItem("clubName", data.name || "ClubSync");
        applyPrimaryColor(data.primaryColor || "#00c853");
        applySecondaryColor(data.secondaryColor || "#3b82f6");
        updateNavBrand(data.logoUrl, data.name);
      }
    } catch (_) {}
  }

  document.getElementById("navbar").classList.remove("hidden");
  document.getElementById("navLinks").classList.remove("open");
  document
    .querySelectorAll(".nav-btn")
    .forEach((b) => b.classList.remove("active"));
  const active = document.querySelector(`[data-nav="${view}"]`);
  if (active) active.classList.add("active");

  const navUser = document.getElementById("navUser");
  if (currentUser) {
    const roleLabel =
      currentUser.role === "admin" ? t("role_admin") : t("role_analyst");
    const initials = (currentUser.name || "?")
      .split(" ")
      .map((p) => p[0])
      .slice(0, 2)
      .join("")
      .toUpperCase();
    navUser.innerHTML = `
      <span class="nav-avatar">${initials}</span>
      <span class="uname">${currentUser.name}
        <span class="badge badge-${currentUser.role === "admin" ? "primary" : "secondary"}"
          style="font-size:.6rem;margin-left:.2rem">${roleLabel}</span>
      </span>`;
  }

  applyI18n();

  const views = {
    dashboard: renderDashboard,
    players: renderPlayers,
    reports: renderReports,
    settings: renderSettings,
  };

  if (views[view]) views[view]();
}

document.addEventListener("DOMContentLoaded", () => {
  applyTheme();

  if (authToken) {
    const savedLogo = localStorage.getItem("clubLogo");
    const savedName = localStorage.getItem("clubName");
    if (savedName) updateNavBrand(savedLogo || "", savedName);
  }

  document.getElementById("themeBtn").addEventListener("click", toggleTheme);
  updateLangBtn();

  document.querySelector(".btn-logout").addEventListener("click", logout);

  document.querySelectorAll(".nav-btn").forEach((btn) => {
    btn.addEventListener("click", () => navigate(btn.dataset.nav));
  });

  // Mobile nav toggle
  const navToggle = document.getElementById("navToggle");
  if (navToggle) {
    navToggle.addEventListener("click", () => {
      document.getElementById("navLinks").classList.toggle("open");
    });
  }

  document.querySelectorAll(".modal-close").forEach((btn) => {
    btn.addEventListener("click", () => closeModal(btn.dataset.close));
  });

  document.querySelectorAll(".modal-overlay").forEach((overlay) => {
    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) closeModal(overlay.id);
    });
  });

  if (authToken) navigate("dashboard");
  else renderLogin();
});
